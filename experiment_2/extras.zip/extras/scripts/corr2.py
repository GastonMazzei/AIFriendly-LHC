import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def filter(d,s,a,b):
  aux = d[d[s].between(a, b, inclusive=False)]
  #print(f'filtered from {len(d)} to {len(aux)} samples!')
  return aux

def process(d,l,s):
  t_1 = filter(d, 'training_accuracy_mean',l,1)
  t_2 = filter(t_1, 'validation_accuracy_mean',l,1)
  return t_2[s].to_frame()

data = pd.read_csv('database.csv')
Y = pd.DataFrame()
name = 'auc'
for i in [0.5,0.75,0.85,0.9,0.91,0.92,0.93,0.94,0.95,0.96]:
  h = process(data,i,name)
  Y = pd.concat([Y,h.rename(columns={name:i})])
f, ax = plt.subplots(1,1)
sns.swarmplot(data=Y,ax=ax)
ax.set_xlabel('Treshold')
ax.set_ylabel('AUC')

ax.set_title('AUC en funcion del (doble) treshold')
f.savefig('PART2_auc.png')

