import pandas as pd
df = pd.read_csv('idmap_manu_sin_cuadrinorm.csv')
import matplotlib.pyplot as plt
f,ax = plt.subplots()
import seaborn as sns
def filtro(d,a,b):
  return d[((d['signal_noise_ratio_train']==a)&(d['signal_noise_ratio_val']==b))]
a = filtro(df,0.5,0.5)
b = filtro(df,0.5,0.02)
c = filtro(df,0.02,0.02)
t = pd.concat([
        pd.DataFrame({'type':'50 50','neurons':a['neurons'],'soft_auc':a['soft_auc']}),
        pd.DataFrame({'type':'50 2','neurons':b['neurons'],'soft_auc':b['soft_auc']}),
        pd.DataFrame({'type':'2 2','neurons':c['neurons'],'soft_auc':c['soft_auc']}),
                 ],axis=0)
sns.scatterplot(x='neurons',y='soft_auc',hue='type',data=t,ax=ax)
f.savefig('two.png')

