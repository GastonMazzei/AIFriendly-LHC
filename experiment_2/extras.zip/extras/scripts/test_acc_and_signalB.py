import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

name = 'database2.csv'

names = [
       'epochs', 
       'batch', 
       'neurons', 
       #'activation', 
       'signal_noise_ratio_train',
       'signal_noise_ratio_val', 
       'signal_noise_ratio_test', 
       'X_train_len',
       'X_val_len', 
       'X_test_len', 
       'training_accuracy_mean', 
       #'validation_accuracy_mean',
       'training_accuracy_std', 
       'validation_accuracy_std',
       'training_loss_mean', 
       'validation_loss_mean', 
       'training_loss_std',
       'validation_loss_std', 
       #'scaler',
       'paradigm',
       'auc', 
       'soft_auc', 
       'f1', 
       #'test_acc',
               ]
d = pd.read_csv(name)
if True: d = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.9,1) & 
               (d['test_acc']/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]

print('LARGO DE D ES ',len(d))
if True: 
  #q = d.nlargest(20,'validation_accuracy_mean')
  q = d.nlargest(50,'test_acc')
else: q = d
if False: df = q[(q['test_acc']/q['validation_accuracy_mean']).between(0.95,1.05)]
#print('LARGO DE F ES ',len(df))
print(q)
#print(df)

f, ax = plt.subplots()
sns.scatterplot(x="signal_noise_ratio_train", y="signal_noise_ratio_test", data=q ,ax=ax)
ax.plot([x/100 for x in range(100)],[x/100 for x in range(100)],c='r',lw='1')
f.savefig('temp.png')

#f, ax = plt.subplots()
#sns.scatterplot(x="signal_noise_ratio_val", y="signal_noise_ratio_test", data=df ,ax=ax)
#f.savefig('temp2.png')


#print(q[['validation_accuracy_mean','test_acc','signal_noise_ratio_val','signal_noise_ratio_test']])
#print(q.columns)














