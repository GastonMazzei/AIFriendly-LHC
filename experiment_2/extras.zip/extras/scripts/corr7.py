import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

name = 'results_sequi_con_cuadrinorm.csv'

def filter(d,s,a,b):
  aux = d[d[s].between(a, b, inclusive=False)]
  print(f'filtered from {len(d)} to {len(aux)} samples!')
  return aux
names = [
       'epochs', 
       'batch', 
       'neurons', 
       #'activation', 
       'signal_noise_ratio_train',
       'signal_noise_ratio_val', 
       'signal_noise_ratio_test', 
       'X_train_len',
       'X_val_len', 
       'X_test_len', 
       'training_accuracy_mean', 
       #'validation_accuracy_mean',
       'training_accuracy_std', 
       'validation_accuracy_std',
       'training_loss_mean', 
       'validation_loss_mean', 
       'training_loss_std',
       'validation_loss_std', 
       #'scaler',
       'paradigm',
       'auc', 
       'soft_auc', 
       'f1', 
       'test_acc',
               ]
f, ax = plt.subplots()
d = pd.read_csv(name)
if False: d = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.9,1) & 
               ((d['validation_accuracy_mean']-d['validation_accuracy_std'])/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]

d = d.drop(names,axis=1)	
q = d.corr()
#want = ['f1','test_acc']
want = ['validation_accuracy_mean']
q = q[want].drop(index=want)
df = q
q = df.assign(m=df.mean(axis=1)).sort_values('m').drop('m', axis=1)
cmap = sns.diverging_palette(145, 280, s=85, l=25, n=7)
sns.heatmap(q,vmin=-1,vmax=1,xticklabels=q.columns, yticklabels=q.index,cmap=cmap,center=0,ax=ax,annot=True)
ax.set_xticklabels(ax.xaxis.get_majorticklabels(), rotation=15)
#c = b.get_figure()
f.suptitle(f'Heatmap for {name}"s correlation',fontsize=16,)
f.savefig('temp.png')

