import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

name = 'database2.csv'

names = [
       'epochs', 
       'batch', 
       'neurons', 
       #'activation', 
       'signal_noise_ratio_train',
       'signal_noise_ratio_val', 
       'signal_noise_ratio_test', 
       'X_train_len',
       'X_val_len', 
       'X_test_len', 
       'training_accuracy_mean', 
       #'validation_accuracy_mean',
       'training_accuracy_std', 
       'validation_accuracy_std',
       'training_loss_mean', 
       'validation_loss_mean', 
       'training_loss_std',
       'validation_loss_std', 
       #'scaler',
       'paradigm',
       'auc', 
       'soft_auc', 
       'f1', 
       #'test_acc',
               ]
d = pd.read_csv(name)
if True: d1 = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.95,1) & 
               ((d['validation_accuracy_mean']-d['validation_accuracy_std'])/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]

if True: d2 = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.9,1) & 
               (d['test_acc']/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]
#N1 = 200
#N2 = 10
#print(len(d1))
print(d1[['validation_accuracy_mean','test_acc']])
#d4 = d1.nsmallest(len(d1)-N1,'validation_accuracy_mean')
#d1 = d1.nlargest(N1,'validation_accuracy_mean')
#q2 = d2.nlargest(N1,'test_acc')
fig = plt.figure()
print(len(d.columns)==len(d1.columns))
if True: d3 = d[~((d['training_accuracy_mean']-d['training_accuracy_std']).between(0.95,1) & 
               ((d['validation_accuracy_mean']-d['validation_accuracy_std'])/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05))]

ax = fig.add_subplot(111, projection='3d')
ax.scatter(d3['signal_noise_ratio_train'],d3['signal_noise_ratio_val'],d3['signal_noise_ratio_test'],c='r',s=5,alpha=0.5)
ax.scatter(d1['signal_noise_ratio_train'],d1['signal_noise_ratio_val'],d1['signal_noise_ratio_test'],c='b',s=50,alpha=1)
#ax.scatter(d4['signal_noise_ratio_train'],d4['signal_noise_ratio_val'],d4['signal_noise_ratio_test'],c='g')
plt.savefig('temp.png')









