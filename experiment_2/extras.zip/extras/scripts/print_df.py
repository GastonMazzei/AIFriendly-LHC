import pandas as pd
from simple import filter_1
import sys

if __name__=='__main__':
  name = sys.argv[1]
  [a,b,c,d] = [float(x) for x in sys.argv[2:]]
  for x in [a,b,c,d]: x = float(x)
  df = pd.read_csv(f'idmap_{name}_cuadrinorm.csv')
  t = filter_1(df,a,b)
  t = t[((t['signal_noise_ratio_train']==c)&(t['signal_noise_ratio_val']==d))]
  print(t[['neurons','soft_auc']])


