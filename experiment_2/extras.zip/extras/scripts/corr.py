import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def filter(d,s,a,b):
  aux = d[d[s].between(a, b, inclusive=False)]
  print(f'filtered from {len(d)} to {len(aux)} samples!')
  return aux
names = [
       'epochs', 
       'batch', 
       'neurons', 
       'activation', 
       'signal_noise_ratio_train',
       'signal_noise_ratio_val', 
       'signal_noise_ratio_test', 
       'X_train_len',
       'X_val_len', 
       'X_test_len', 
       #'training_accuracy_mean', 
       #'validation_accuracy_mean',
       'training_accuracy_std', 
       'validation_accuracy_std',
       'training_loss_mean', 
       'validation_loss_mean', 
       'training_loss_std',
       'validation_loss_std', 
       'scaler',
       'paradigm',
       'auc', 
       'soft_auc', 
       'f1', 
       #'test_acc',
               ]
f, ax = plt.subplots(1,3,gridspec_kw={'width_ratios': [2,3, 1]},figsize=(15,8))
#sns.color_palette("BuGn_r")
d = pd.read_csv('database.csv')
treshold = 0.85
#d = filter(d,'signal_noise_ratio_train',0.4,0.6)
d = filter(d,'training_accuracy_mean',treshold,1)
d = filter(d, 'validation_accuracy_mean',treshold,1)
#d = filter(d, 'test_acc',treshold,1)
#d = filter(d, 'f1',0.9,1)
#d = filter(d, 'test_acc',0.9,1)
#d = filter(d, 'auc',0.9,1)
d = d.drop(names,axis=1)	
q = d.corr()
#q = q[['auc', 'f1', 'test_acc']].drop(index=['auc', 'f1', 'test_acc'])
#q = q['validation_accuracy_mean'].drop(index=['validation_accuracy_mean']).to_frame()
df = q
#print(q)
q = df.assign(m=df.mean(axis=1)).sort_values('m').drop('m', axis=1)
#print(q)
cmap = sns.diverging_palette(145, 280, s=85, l=25, n=7)
sns.heatmap(q,vmin=-1,vmax=1,xticklabels=q.columns, yticklabels=q.index,cmap=cmap,center=0,ax=ax[1],annot=True)
#ax[1].set_title('Corr("hyper-parameters","accuracy measures")') 
ax[1].set_title('Corr("training-accuracy","validation-accuracy","test-accuracy")') 
#sns.swarmplot(data=d[['auc', 'f1', 'test_acc']],ax=ax[2])#,hue=d.columns)
sns.swarmplot(data=d[['test_acc']],ax=ax[2])#,hue=d.columns)
ax[2].set_title('testing accuracy mean swarm plot')
ax[2].set_ylim(0,1)
#sns.swarmplot(data=d[['signal_noise_ratio_train', 'signal_noise_ratio_val', 'signal_noise_ratio_test']],ax=ax[0])
sns.swarmplot(data=d[['training_accuracy_mean','validation_accuracy_mean']],ax=ax[0])
ax[0].set_title('training/valid accuracy mean swarm plot')
ax[0].set_xticklabels(ax[0].xaxis.get_majorticklabels(), rotation=15)
ax[1].set_xticklabels(ax[1].xaxis.get_majorticklabels(), rotation=15)
ax[0].set_ylim(0,1)
#c = b.get_figure()
f.suptitle('Caso validation y training acc +85% para [100 samples]',fontsize=16,)
f.savefig('temp.png')

