import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

name = 'database2.csv'
name = 'results_sequi_con_cuadrinorm.csv'
names = [
       'epochs', 
       'batch', 
       'neurons', 
       #'activation', 
       'signal_noise_ratio_train',
       'signal_noise_ratio_val', 
       'signal_noise_ratio_test', 
       'X_train_len',
       'X_val_len', 
       'X_test_len', 
       'training_accuracy_mean', 
       #'validation_accuracy_mean',
       'training_accuracy_std', 
       'validation_accuracy_std',
       'training_loss_mean', 
       'validation_loss_mean', 
       'training_loss_std',
       'validation_loss_std', 
       #'scaler',
       'paradigm',
       'auc', 
       'soft_auc', 
       'f1', 
       #'test_acc',
               ]
f, ax = plt.subplots()
d = pd.read_csv(name)
if True: d = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.95,1) & 
               ((d['validation_accuracy_mean']-d['validation_accuracy_std'])/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]

print('LARGO DE D ES ',len(d))
if False: q = d.nlargest(20,'validation_accuracy_mean')
else: q = d

sns.scatterplot(x="signal_noise_ratio_train", y="signal_noise_ratio_val", data=q ,ax=ax)

print(q[['validation_accuracy_mean','test_acc']])
#print(q.columns)
f.savefig('temp.png')














