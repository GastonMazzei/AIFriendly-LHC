import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

name = 'database2.csv'

names = [
       'epochs', 
       'batch', 
       'neurons', 
       #'activation', 
       'signal_noise_ratio_train',
       'signal_noise_ratio_val', 
       'signal_noise_ratio_test', 
       'X_train_len',
       'X_val_len', 
       'X_test_len', 
       'training_accuracy_mean', 
       #'validation_accuracy_mean',
       'training_accuracy_std', 
       'validation_accuracy_std',
       'training_loss_mean', 
       'validation_loss_mean', 
       'training_loss_std',
       'validation_loss_std', 
       #'scaler',
       'paradigm',
       'auc', 
       'soft_auc', 
       'f1', 
       #'test_acc',
               ]
d = pd.read_csv(name)
if True: d1 = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.9,1) & 
               ((d['validation_accuracy_mean']-d['validation_accuracy_std'])/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]

if True: d2 = d[(d['training_accuracy_mean']-d['training_accuracy_std']).between(0.9,1) & 
               (d['test_acc']/
                  (d['training_accuracy_mean']+d['training_accuracy_std'])).between(0.95,1.05)]
N1 = 20
N2 = 10
q1 = d1.nlargest(N1,'validation_accuracy_mean')
q2 = d2.nlargest(N1,'test_acc')

print(len(q1),len(q2))
q1b = d1.nlargest(N2,'test_acc')
q2b = d2.nlargest(N2,'validation_accuracy_mean')
t = pd.DataFrame({'signal_noise_ratio_val': q1b['signal_noise_ratio_val'],
                   #'val_signal_testfiltered': q2b['signal_noise_ratio_val'],
                   'signal_noise_ratio_test': q1b['signal_noise_ratio_test'],
                   #'test_signal_testfiltered': q2b['signal_noise_ratio_test'],
                   'filter':'val-filtered'
                   })
t = pd.concat([t,pd.DataFrame({'signal_noise_ratio_val': q2b['signal_noise_ratio_val'],
                   #'val_signal_testfiltered': q2b['signal_noise_ratio_val'],
                   'signal_noise_ratio_test': q2b['signal_noise_ratio_test'],
                   #'test_signal_testfiltered': q2b['signal_noise_ratio_test'],
                   'filter':'test-filtered'
                   })])
f, ax = plt.subplots()
#sns.scatterplot(x="signal_noise_ratio_val", y="signal_noise_ratio_test", data=q1b ,ax=ax,alpha=0.5)
#sns.scatterplot(x="signal_noise_ratio_val", y="signal_noise_ratio_test", data=q2b ,ax=ax,alpha=0.5)
sns.scatterplot(x="signal_noise_ratio_val", y="signal_noise_ratio_test", size='filter',hue='filter',data=t ,ax=ax,alpha=0.7)
#sns.lineplot(x="signal_noise_ratio_val", y="signal_noise_ratio_test", hue='filter',data=t ,ax=ax,alpha=0.7)
ax.set_xlim(0,1)
ax.set_ylim(0,1)
f.savefig('temp.png')









