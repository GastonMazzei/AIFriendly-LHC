import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def filter(d,s,a,b):
  aux = d[d[s].between(a, b, inclusive=False)]
  #print(f'filtered from {len(d)} to {len(aux)} samples!')
  return aux

def process(d,l,s):
  t_1 = filter(d, 'training_accuracy_mean',l,1)
  t_2 = filter(t_1, 'validation_accuracy_mean',l,1)
  return t_2.corr().loc[s]

data = pd.read_csv('database.csv')
Y = pd.DataFrame(columns = data.columns)
name = 'auc'
X = [0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95]#0.91,0.92,0.93,0.94,0.95,0.96]
#X = [0.5,0.7]
for i in X:
  Y = Y.append(process(data,i,name))
Y['treshold'] = X
Y = Y.set_index('treshold')
print(Y)

keep1 = [
        'signal_noise_ratio_test',
        'signal_noise_ratio_train',
        'signal_noise_ratio_val',
        'epochs',
        'neurons',]
keep2 = [
        'activation',
        'paradigm',
        'scaler',
        'batch',
            ]
keep3 =  [
        'signal_noise_ratio_test',
        'signal_noise_ratio_train',
        'signal_noise_ratio_val',
        'epochs',
        'neurons',
        'activation',
        'paradigm',
        'scaler',
        'batch',
            ]
dash_styles = ["",
               (4, 1.5),
               (1, 1),
               (3, 1, 1.5, 1),
               (5, 1, 1, 1),
               (5, 1, 2, 1, 2, 1),
               (2, 2, 3, 1.5),
               (1, 2.5, 3, 1.2),
               ""]
def repeat(n,globalname,Y):
  f, ax = plt.subplots(1,1)
  if n==1:  Y = Y[keep1]
  elif n==2: Y = Y[keep2]
  else: Y = Y[keep3]
  sns.lineplot(data=Y,ax=ax, dashes=dash_styles)
  ax.set_xlabel('Treshold')
  ax.set_ylabel(f'Corr("smth","{globalname}")')
  ax.set_ylim(-1,1)
  ax.set_title(f'Correlation with {globalname} en funcion del treshold ({n}de3)')
  ax.legend(loc=3)
  f.savefig(f'infograph/{globalname}_corrline_{n}.png')

for x in [1,2,3]:
  repeat(x,name,Y)
